# TickPoint Combat

A tactical, tick-based action point combat system for RuneQuest Glorantha in Foundry VTT.

## Features
- Speed and Action Point calculation per actor
- Tick-based initiative highlighting
- Long actions tracked across multiple ticks
- Cancel buttons for players (on their tick) and GMs
- AP override support in item sheets
- Custom GM-configurable AP costs and formulas
- History log with per-user visibility
- Sound and animation support for actions

## Installation
Use the Foundry Module Manager and install via this manifest URL:
```
https://example.com/tickpoint-combat/module.json
```

## License
MIT
