// File: modules/tickpoint-combat/scripts/long-action.js

import { logToHistory } from "./history-log.js";
import { getCurrentAP, setCurrentAP } from "./ap-utils.js";
import { isCombatActive } from "./helpers.js";

const longActions = new Map(); // actorId => { ticksRemaining, label, apCost }

export function registerLongActionSystem() {
  Hooks.on("tickpoint-tick-start", handleTick);
  Hooks.on("deleteCombat", () => longActions.clear());
  Hooks.on("deleteActor", actor => longActions.delete(actor.id));
}

export function startLongAction(actor, { label = "Long Action", ticks = 3, apCost = 0 } = {}) {
  if (!actor) return;
  const currentAP = getCurrentAP(actor);
  if (currentAP < apCost) {
    ui.notifications.warn("Not enough AP to start long action.");
    return;
  }

  setCurrentAP(actor, currentAP - apCost);
  logToHistory(actor, `Started long action "${label}" (${ticks} ticks)`);
  longActions.set(actor.id, { ticksRemaining: ticks, label, apCost });

  Hooks.call("tickpoint-long-action-start", actor, { label, ticks, apCost });
  Hooks.call("tickpoint-ap-updated", actor);
}

function handleTick(currentTick) {
  if (!isCombatActive()) return;

  for (let [actorId, action] of longActions.entries()) {
    const actor = game.actors.get(actorId);
    if (!actor) {
      longActions.delete(actorId);
      continue;
    }

    action.ticksRemaining--;

    Hooks.call("tickpoint-long-action-progress", actor, action);

    if (action.ticksRemaining <= 0) {
      completeLongAction(actor, action);
    }
  }
}

function completeLongAction(actor, action) {
  if (!actor) return;
  logToHistory(actor, `Completed long action "${action.label}"`);
  longActions.delete(actor.id);
  Hooks.call("tickpoint-long-action-complete", actor, action);
}

export function initializeLongAction() {
  game.tickpoint.longAction = new LongAction();
}

class LongAction {
  constructor() {
    this.rendered = false;
  }

  /**
   * @param {number} progress - Current progress percentage (0-100)
   * @param {string} actionLabel - Label of the ongoing action
   * @param {boolean} canCancel - Whether the action can be cancelled
   */
  async render(progress = 0, actionLabel = "", canCancel = true) {
    const html = await renderTemplate("modules/tickpoint-combat/templates/long-action.html", {
      progress,
      actionLabel,
      canCancel
    });

    if (!this.element) {
      this.element = document.createElement("div");
      this.element.classList.add("tickpoint-long-action");
      document.body.appendChild(this.element);
    }
    this.element.innerHTML = html;

    this._attachListeners();

    this.rendered = true;
  }

  _attachListeners() {
    this.element.querySelector(".cancel-action")?.addEventListener("click", () => {
      // Emit hook that long action was cancelled
      Hooks.call("tickpoint-long-action-cancelled");
      this.close();
    });
  }

  close() {
    if (this.element) this.element.remove();
    this.rendered = false;
  }
}
