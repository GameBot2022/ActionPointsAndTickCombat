// File: modules/tickpoint-combat/scripts/tickpoint.js

import { registerSettings } from "./settings.js";
import { initializeAPTracker } from "./ap-tracker.js";
import { TickScheduler } from "./tick-scheduler.js";
import { setupGMPanel } from "./gm-panel.js";
import { setupQuickActions } from "./quick-actions.js";
import { initializeLongActions } from "./long-action.js";
import { initializeCustomActions } from "./custom-actions.js";
import { performCleanup } from "./cleanup.js";

class TickPointCombatModule {
  constructor() {
    this.tickScheduler = null;
    this.initialized = false;
  }

  async initialize() {
    console.log("TickPoint Combat | Initializing module...");

    // 1. Register module settings
    registerSettings();

    // 2. Initialize AP tracking system
    initializeAPTracker();

    // 3. Initialize Tick Scheduler instance
    this.tickScheduler = new TickScheduler();

    // 4. Setup GM panel UI and Quick Actions UI
    setupGMPanel();
    setupQuickActions();

    // 5. Initialize Long Actions system
    initializeLongActions();

    // 6. Initialize Custom Actions system
    initializeCustomActions();

    // 7. Setup Hooks for combat lifecycle and actor updates
    this._setupHooks();

    this.initialized = true;
    console.log("TickPoint Combat | Initialization complete.");
  }

  _setupHooks() {
    // Hook into Foundry Combat creation to initialize Tick Scheduler
    Hooks.on("createCombat", async (combat) => {
      if (!this.initialized) return;
      await this.tickScheduler.initialize(combat);
    });

    // Hook into Combat update (round changes)
    Hooks.on("updateCombat", async (combat, changed) => {
      if (!this.initialized) return;
      if (changed.round !== undefined) {
        await this.tickScheduler._onNewRound(combat);
      }
    });

    // Hook into Combat deletion to cleanup Tick Scheduler state
    Hooks.on("deleteCombat", async (combat) => {
      if (!this.initialized) return;
      await this.tickScheduler.cleanup();
    });

    // Hook for actor updates to sync speed/AP if formulas change
    Hooks.on("updateActor", async (actor, changed) => {
      if (!this.initialized) return;
      // If relevant data changes, refresh actor AP and TickScheduler data
      if (changed.data?.attributes?.speed || changed.flags?.["tickpoint-combat"]) {
        await this.tickScheduler.refreshActor(actor);
      }
    });

    // Hook for custom action use (deduct AP)
    Hooks.on("tickpoint-custom-action-used", async (actor, action) => {
      if (!this.initialized) return;
      // AP deduction and UI update handled by ap-tracker.js
      // Could trigger tick scheduler updates here if necessary
    });

    // Hook for AP updates - sync UI components or other modules
    Hooks.on("tickpoint-ap-updated", (actor) => {
      if (!this.initialized) return;
      // Refresh UI panels related to this actor�s AP
      setupQuickActions().refreshForActor(actor);
      setupGMPanel().refreshForActor(actor);
    });

    // Module disable/uninstall hook for cleanup
    Hooks.on("disableModule", async (moduleName) => {
      if (moduleName === "tickpoint-combat") {
        await performCleanup();
      }
    });

    Hooks.on("preUninstallModule", async (moduleName) => {
      if (moduleName === "tickpoint-combat") {
        await performCleanup();
      }
    });
  }
}

// Instantiate and initialize the module on Foundry ready
Hooks.once("ready", async () => {
  const tickpointModule = new TickPointCombatModule();
  await tickpointModule.initialize();
});

