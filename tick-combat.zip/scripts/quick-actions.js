import { getCustomActions } from "./custom-actions.js";
import { getCurrentAP } from "./ap-utils.js";

export function initializeQuickActions() {
  game.tickpoint.quickActions = new QuickActions();
}

class QuickActions {
  constructor() {
    this.rendered = false;
  }

  async render(force = false) {
    if (this.rendered && !force) return;
    const actions = getCustomActions(); // Pull current actions from state/storage
    const actor = canvas.tokens.controlled[0]?.actor;
    const currentAP = actor ? getCurrentAP(actor) : 0;

    const html = await renderTemplate("modules/tickpoint-combat/templates/quick-actions.html", {
      actions,
      currentAP
    });

    if (!this.element) {
      this.element = document.createElement("div");
      this.element.classList.add("tickpoint-quick-actions");
      document.body.appendChild(this.element);
    }
    this.element.innerHTML = html;

    this._attachListeners();

    this.rendered = true;
  }

  _attachListeners() {
    this.element.querySelectorAll(".quick-action-button").forEach(button => {
      button.addEventListener("click", async (event) => {
        const actionId = button.dataset.actionId;
        const actor = canvas.tokens.controlled[0]?.actor;
        if (!actor) return ui.notifications.warn("Select a token first.");
        const action = getCustomActions().find(a => a.id === actionId);
        if (!action) return;

        // Check AP
        const currentAP = getCurrentAP(actor);
        if (currentAP < (action.apCost || 0)) {
          return ui.notifications.warn("Not enough AP for that action.");
        }

        // Deduct AP and emit hook
        Hooks.call("tickpoint-custom-action-used", actor, action);
      });
    });
  }

  close() {
    if (this.element) this.element.remove();
    this.rendered = false;
  }
}
