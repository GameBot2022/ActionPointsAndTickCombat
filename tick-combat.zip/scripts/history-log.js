// File: modules/tickpoint-combat/scripts/history-log.js

/**
 * Logs action history entries for actors, with visibility control.
 * Stores logs as actor flags and optionally persists across sessions.
 */

const HISTORY_FLAG = "tickpoint-combat.historyLog";
const MAX_HISTORY_LENGTH = 100;

/**
 * Log a message entry for a specific actor.
 * @param {Actor} actor - The actor to log for.
 * @param {string} message - The log message.
 * @param {Object} options - Optional settings:
 *   - {boolean} visibleToPlayers - If false, only GMs see this log entry (default true).
 */
export async function logToHistory(actor, message, options = {}) {
  if (!actor) return;
  const visibleToPlayers = options.visibleToPlayers ?? true;
  const timestamp = getTimestamp();
  const entry = {
    timestamp,
    message,
    visibleToPlayers,
  };

  // Get current log or empty array
  let history = actor.getFlag("tickpoint-combat", "historyLog") || [];

  // Append new entry
  history.push(entry);

  // Limit history size
  if (history.length > MAX_HISTORY_LENGTH) {
    history = history.slice(history.length - MAX_HISTORY_LENGTH);
  }

  await actor.setFlag("tickpoint-combat", "historyLog", history);

  // Notify any listeners
  Hooks.call("tickpoint-history-updated", actor, history);
}

/**
 * Retrieve the history log entries for an actor.
 * Optionally filter by visibility (e.g., only GM-visible).
 * @param {Actor} actor
 * @param {Object} options
 *   - {boolean} forGM - If true, returns all logs; else filters by visibleToPlayers=true.
 * @returns {Array} Array of log entries.
 */
export function getHistoryLog(actor, options = {}) {
  if (!actor) return [];
  const forGM = options.forGM ?? false;
  const history = actor.getFlag("tickpoint-combat", "historyLog") || [];
  if (forGM) return history;
  return history.filter(entry => entry.visibleToPlayers !== false);
}

/**
 * Clear the entire history log for an actor.
 * @param {Actor} actor
 */
export async function clearHistoryLog(actor) {
  if (!actor) return;
  await actor.unsetFlag("tickpoint-combat", "historyLog");
  Hooks.call("tickpoint-history-cleared", actor);
}

/**
 * Clear history logs for all combatants in a combat.
 * @param {Combat} combat
 */
export async function clearHistoryForCombatants(combat) {
  if (!combat) return;
  for (let combatant of combat.combatants) {
    if (combatant.actor) {
      await clearHistoryLog(combatant.actor);
    }
  }
}

/**
 * Get a formatted string representation of the history log entries,
 * for display in a UI panel or console.
 * @param {Array} historyEntries
 * @returns {string}
 */
export function formatHistoryEntries(historyEntries) {
  return historyEntries.map(entry => `[${entry.timestamp}] ${entry.message}`).join("\n");
}

/**
 * Get current timestamp formatted string.
 * @returns {string}
 */
function getTimestamp() {
  const now = new Date();
  const pad = (n) => n.toString().padStart(2, "0");
  const year = now.getFullYear();
  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());
  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * Hook example usage for auto-refresh UI when history updates:
 * Hooks.on("tickpoint-history-updated", (actor, history) => {
 *   // Refresh your module UI here
 * });
 */

