// File: modules/tickpoint-combat/scripts/tick-scheduler.js

import { getActorSpeedTicks } from "./ap-utils.js";
import { getSetting } from "./settings.js";
import { logToHistory } from "./history-log.js";
import { updateTickTrackerUI, animateTickProgress } from "./tick-tracker.js";
import { handleLongActionsTick } from "./long-action.js";

export class TickScheduler {
  constructor() {
    this.currentTick = 0;
    this.maxTicks = getSetting("maxTicks") || 30;
    this.tickDuration = getSetting("tickDuration") || 1000; // in ms
    this.intervalId = null;
    this.combat = null;
  }

  initialize(combat) {
    this.combat = combat;
    this.maxTicks = getSetting("maxTicks") || 30;
    this.tickDuration = getSetting("tickDuration") || 1000;
    this.currentTick = 0;
    this._start();
  }

  _start() {
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = setInterval(() => this._processTick(), this.tickDuration);
  }

  stop() {
    clearInterval(this.intervalId);
    this.intervalId = null;
    this.currentTick = 0;
    updateTickTrackerUI(null);
  }

  _processTick() {
    if (!this.combat) return;
    this.currentTick++;
    if (this.currentTick > this.maxTicks) {
      this.currentTick = 1;
      this._onNewRound();
    }

    animateTickProgress(this.currentTick);
    this._refreshUI();
    this._handleEligibleTurns();
    handleLongActionsTick(this.currentTick);
  }

  _onNewRound() {
    logToHistory(null, `New Round Started`);
  }

  _refreshUI() {
    updateTickTrackerUI(this.currentTick);
  }

  _handleEligibleTurns() {
    const actors = this.combat.combatants.map(c => c.actor).filter(Boolean);
    for (let actor of actors) {
      const ticks = getActorSpeedTicks(actor);
      if (ticks.includes(this.currentTick)) {
        this._processCombatantTurn(actor);
      }
    }
  }

  _processCombatantTurn(actor) {
    logToHistory(actor, `Eligible to act on Tick ${this.currentTick}`);
    Hooks.call("tickpoint-actor-eligible", actor, this.currentTick);
  }
}

// Singleton instance
export const TickSchedulerInstance = new TickScheduler();

Hooks.on("createCombat", combat => {
  if (!combat) return;
  TickSchedulerInstance.initialize(combat);
});

Hooks.on("deleteCombat", () => {
  TickSchedulerInstance.stop();
});

Hooks.on("updateCombat", (combat, changes) => {
  if (changes.round !== undefined) {
    TickSchedulerInstance.initialize(combat);
  }
});
