// File: modules/tickpoint-combat/scripts/custom-actions.js

import { getTimestamp } from "./helpers.js";
import { logToHistory } from "./history-log.js";
import { getCurrentAP, setCurrentAP } from "./ap-utils.js";

const CUSTOM_ACTIONS_SETTING = "tickpoint-combat.customActions";

// Returns all stored custom actions
export function getCustomActions() {
  return game.settings.get("tickpoint-combat", "customActions") || [];
}

// Saves the given list of actions to the setting
export function saveCustomActions(actions) {
  return game.settings.set("tickpoint-combat", "customActions", actions);
}

// Adds a new custom action
export async function addCustomAction({ label, apCost, category = "", icon = "", createdAt = getTimestamp() }) {
  const actions = getCustomActions();
  actions.push({ id: randomID(), label, apCost, category, icon, createdAt });
  return saveCustomActions(actions);
}

// Updates an existing action by ID
export async function updateCustomAction(id, updates) {
  const actions = getCustomActions().map(action => {
    if (action.id === id) return { ...action, ...updates };
    return action;
  });
  return saveCustomActions(actions);
}

// Deletes a custom action by ID
export async function deleteCustomAction(id) {
  const actions = getCustomActions().filter(action => action.id !== id);
  return saveCustomActions(actions);
}

// Returns a list of actions filtered by category (if provided)
export function getActionsByCategory(category = null) {
  const actions = getCustomActions();
  return category ? actions.filter(a => a.category === category) : actions;
}

// Uses a custom action on the given actor
export async function useCustomAction(actor, actionId) {
  const action = getCustomActions().find(a => a.id === actionId);
  if (!actor || !action) return;

  const currentAP = getCurrentAP(actor);
  const cost = action.apCost || 0;
  if (currentAP < cost) {
    ui.notifications.warn("Not enough AP");
    return;
  }

  await setCurrentAP(actor, currentAP - cost);
  logToHistory(actor, `Used custom action: ${action.label} (-${cost} AP)`);

  Hooks.call("tickpoint-custom-action-used", actor, action);
  Hooks.call("tickpoint-ap-updated", actor);
}
