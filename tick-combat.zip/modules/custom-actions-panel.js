// File: modules/tickpoint-combat/scripts/custom-actions-panel.js

import {
  getCustomActions,
  addCustomAction,
  updateCustomAction,
  removeCustomAction,
  getCustomActionById
} from "./custom-actions.js";

export class CustomActionsPanel extends Application {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      id: "custom-actions-panel",
      title: "Custom Actions Manager",
      template: "modules/tickpoint-combat/templates/custom-actions-panel.html",
      width: 600,
      height: "auto",
      resizable: true,
      classes: ["tickpoint", "custom-actions"],
    });
  }

  getData() {
    return {
      actions: getCustomActions(),
    };
  }

  activateListeners(html) {
    super.activateListeners(html);

    // Create new action
    html.find(".action-create").on("click", async () => {
      const name = html.find("input[name='new-name']").val()?.trim();
      const apCost = parseInt(html.find("input[name='new-apCost']").val()) || 0;
      const category = html.find("input[name='new-category']").val()?.trim();
      const icon = html.find("input[name='new-icon']").val()?.trim();

      if (!name) {
        return ui.notifications.warn("Action must have a name.");
      }

      const existing = getCustomActions().some(a => a.name === name);
      if (existing) {
        return ui.notifications.warn("An action with this name already exists.");
      }

      await addCustomAction({ name, apCost, category, icon });
      this.render();
    });

    // Edit existing action
    html.find(".action-edit").on("click", async (event) => {
      const actionId = event.currentTarget.dataset.id;
      if (!actionId) {
        return ui.notifications.error("No action ID specified for edit.");
      }

      const row = html.find(`.action-row[data-id='${actionId}']`);
      const updatedName = row.find("input[name='name']").val()?.trim();
      const apCost = parseInt(row.find("input[name='apCost']").val()) || 0;
      const category = row.find("input[name='category']").val()?.trim();
      const icon = row.find("input[name='icon']").val()?.trim();

      if (!updatedName) {
        return ui.notifications.warn("Name cannot be empty.");
      }

      // Update action by id (not name, as names can change)
      await updateCustomAction(actionId, { name: updatedName, apCost, category, icon });
      this.render();
    });

    // Delete action
    html.find(".action-delete").on("click", async (event) => {
      const actionId = event.currentTarget.dataset.id;
      if (!actionId) {
        return ui.notifications.error("No action ID specified for deletion.");
      }
      await removeCustomAction(actionId);
      this.render();
    });
  }
}
