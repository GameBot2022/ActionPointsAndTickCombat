// File: modules/tickpoint-combat/scripts/combat-enhancements.js

import {
  getCurrentAP,
  deductAP,
  restoreAP,
  resetAP,
} from "./ap-utils.js";

/**
 * CombatEnhancements class manages UI and hooks related to AP display
 * and quick AP adjustments during combat.
 */
export class CombatEnhancements {
  constructor() {
    this.apDisplaySelector = ".tickpoint-ap-display";
    this._onTickpointAPUpdated = this._onTickpointAPUpdated.bind(this);
  }

  /**
   * Initialize hooks and render initial UI enhancements.
   */
  initialize() {
    Hooks.on("tickpoint-ap-updated", this._onTickpointAPUpdated);
    Hooks.on("updateCombat", () => this._renderAPForCurrentCombatant());
    Hooks.on("renderCombatTracker", () => this._renderAPForCurrentCombatant());

    // Initial render if combat is active
    if (game.combat?.current?.tokenId) {
      this._renderAPForCurrentCombatant();
    }
  }

  /**
   * Handler for tickpoint-ap-updated hook: refresh UI for relevant actor.
   * @param {Actor} actor
   */
  async _onTickpointAPUpdated(actor) {
    if (!actor) return;
    this._renderAPForCurrentCombatant();
  }

  /**
   * Render or update AP display for the current combatant in the Combat Tracker.
   */
  async _renderAPForCurrentCombatant() {
    const combatant = game.combat?.current;
    if (!combatant) return;

    const actor = combatant.actor;
    if (!actor) return;

    // Find the combat tracker entry element for this combatant's token
    const combatTracker = document.querySelector("#combat-tracker");
    if (!combatTracker) return;

    const combatantElement = combatTracker.querySelector(`[data-combatant-id="${combatant.id}"]`);
    if (!combatantElement) return;

    // Remove existing AP display if present, else create it
    let apDisplay = combatantElement.querySelector(this.apDisplaySelector);
    if (!apDisplay) {
      apDisplay = document.createElement("div");
      apDisplay.classList.add(this.apDisplaySelector.substring(1)); // Remove dot from selector
      apDisplay.style.marginTop = "0.3em";
      apDisplay.style.fontWeight = "600";
      apDisplay.style.display = "flex";
      apDisplay.style.gap = "0.5em";
      apDisplay.style.alignItems = "center";

      // Insert after combatant name element
      const nameElement = combatantElement.querySelector(".combatant-name");
      if (nameElement && nameElement.parentNode) {
        nameElement.parentNode.insertBefore(apDisplay, nameElement.nextSibling);
      } else {
        combatantElement.appendChild(apDisplay);
      }
    }

    // Get current AP and max AP from flags or AP utils
    const currentAP = getCurrentAP(actor);
    const maxAP = actor.getFlag("tickpoint-combat", "maxAP") ?? 0;

    apDisplay.innerHTML = `
      <span title="Current AP / Max AP" style="color: #1a73e8;">
        ? AP: ${currentAP} / ${maxAP}
      </span>
      <button class="ap-restore-btn" title="Restore 1 AP" style="background-color: #28a745; border:none; color:#fff; border-radius:3px; padding:2px 6px; cursor:pointer;">
        <i class="fas fa-plus"></i>
      </button>
      <button class="ap-deduct-btn" title="Deduct 1 AP" style="background-color: #dc3545; border:none; color:#fff; border-radius:3px; padding:2px 6px; cursor:pointer;">
        <i class="fas fa-minus"></i>
      </button>
      <button class="ap-reset-btn" title="Reset AP to max" style="background-color: #007bff; border:none; color:#fff; border-radius:3px; padding:2px 6px; cursor:pointer;">
        <i class="fas fa-sync-alt"></i>
      </button>
    `;

    // Attach listeners for AP buttons
    const restoreBtn = apDisplay.querySelector(".ap-restore-btn");
    const deductBtn = apDisplay.querySelector(".ap-deduct-btn");
    const resetBtn = apDisplay.querySelector(".ap-reset-btn");

    restoreBtn.onclick = async (evt) => {
      evt.stopPropagation();
      await restoreAP(actor, 1);
      ui.notifications.info(`Restored 1 AP for ${actor.name}.`);
    };

    deductBtn.onclick = async (evt) => {
      evt.stopPropagation();
      const success = await deductAP(actor, 1);
      if (success) {
        ui.notifications.info(`Deducted 1 AP from ${actor.name}.`);
      } else {
        ui.notifications.warn(`${actor.name} does not have enough AP to deduct.`);
      }
    };

    resetBtn.onclick = async (evt) => {
      evt.stopPropagation();
      await resetAP(actor);
      ui.notifications.info(`Reset AP to max for ${actor.name}.`);
    };
  }
}

/**
 * Initialize combat enhancements after Foundry is ready.
 */
export function initializeCombatEnhancements() {
  Hooks.once("ready", () => {
    const enhancements = new CombatEnhancements();
    enhancements.initialize();
    game.tickpoint = game.tickpoint || {};
    game.tickpoint.combatEnhancements = enhancements;
  });
}
