// File: modules/tickpoint-combat/scripts/quick-actions.js

import { QuickActionsPanel } from "./quick-actions-panel.js";
import { deductAP } from "./ap-utils.js";

export function initializeQuickActions() {
  game.tickpoint = game.tickpoint || {};
  game.tickpoint.quickActions = new QuickActionsPanel();

  // Initial render when Foundry is ready
  Hooks.once("ready", () => {
    game.tickpoint.quickActions.render();
  });

  // Re-render quick actions when the controlled token's actor AP updates
  Hooks.on("tickpoint-ap-updated", (actor) => {
    const controlledActor = canvas.tokens.controlled[0]?.actor;
    if (controlledActor && actor?.id === controlledActor.id) {
      game.tickpoint.quickActions.render(true);
    }
  });

  // Render or close quick actions panel on token control changes
  Hooks.on("controlToken", (_token, controlled) => {
    if (controlled) {
      game.tickpoint.quickActions.render(true);
    } else {
      game.tickpoint.quickActions.close();
    }
  });
}

/**
 * Attempt to use a quick action by deducting AP and firing the appropriate hook.
 * @param {Actor} actor
 * @param {Object} action
 * @returns {Promise<boolean>} true if AP deducted successfully, else false
 */
export async function useQuickAction(actor, action) {
  if (!actor || !action) return false;

  const success = await deductAP(actor, action.apCost);
  if (!success) {
    ui.notifications.warn("Not enough AP for that action.");
    return false;
  }

  Hooks.call("tickpoint-custom-action-used", actor, action);
  return true;
}
