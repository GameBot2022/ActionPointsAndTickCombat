// File: modules/tickpoint-combat/scripts/gm-panel.js

import {
  getCustomActions,
  setCustomActions,
  removeCustomAction,
} from "./custom-actions.js";

import {
  getHistoryLog,
  clearHistoryLog,
  logToHistory,
  exportHistory,
} from "./history-log.js";

import { deductAP, restoreAP } from "./ap-utils.js";

const PANEL_ID = "tickpoint-gm-panel";

export class GMPanel extends Application {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      id: PANEL_ID,
      title: "TickPoint Combat � GM Panel",
      template: "modules/tickpoint-combat/templates/gm-panel.html",
      width: 700,
      height: "auto",
      resizable: true,
      classes: ["tickpoint", "gm-panel"],
    });
  }

  async getData() {
    const customActions = getCustomActions();
    const history = [];

    for (const actor of game.actors.contents) {
      const entries = getHistoryLog(actor, { forGM: true });
      const currentAP = actor.getFlag("tickpoint-combat", "currentAP") ?? 0;
      history.push({ actor, entries, currentAP });
    }

    return { customActions, history };
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find(".add-action").on("click", async () => {
      const label = prompt("Enter action label:");
      if (!label?.trim()) return ui.notifications.warn("Action label is required.");

      const apCost = parseInt(prompt("Enter AP cost:"), 10);
      if (isNaN(apCost) || apCost < 0) return ui.notifications.error("Invalid AP cost.");

      const icon = prompt("Enter icon class (e.g., 'fas fa-sword'):", "fas fa-question");
      const category = prompt("Enter category:", "General");

      const newAction = {
        id: randomID(),
        label,
        apCost,
        icon,
        category,
        createdAt: new Date().toISOString(),
      };

      const actions = getCustomActions();
      actions.push(newAction);
      await setCustomActions(actions);
      this.render();
    });

    html.find(".edit-action").on("click", async (event) => {
      const actionId = event.currentTarget.closest("[data-action-id]")?.dataset?.actionId;
      if (!actionId) return ui.notifications.error("No action ID specified.");

      const actions = getCustomActions();
      const action = actions.find((a) => a.id === actionId);
      if (!action) return ui.notifications.error("Action not found.");

      const label = prompt("Edit action label:", action.label);
      if (!label?.trim()) return ui.notifications.warn("Action label is required.");

      const apCost = parseInt(prompt("Edit AP cost:", action.apCost), 10);
      if (isNaN(apCost) || apCost < 0) return ui.notifications.error("Invalid AP cost.");

      const icon = prompt("Edit icon class:", action.icon) || "fas fa-question";
      const category = prompt("Edit category:", action.category) || "General";

      const updatedAction = { ...action, label, apCost, icon, category };
      const updatedActions = actions.map((a) => (a.id === actionId ? updatedAction : a));

      await setCustomActions(updatedActions);
      this.render();
    });

    html.find(".delete-action").on("click", async (event) => {
      const actionId = event.currentTarget.closest("[data-action-id]")?.dataset?.actionId;
      if (!actionId) return ui.notifications.error("No action ID specified.");

      if (!confirm("Are you sure you want to delete this action?")) return;

      await removeCustomAction(actionId);
      this.render();
    });

    html.find(".use-action").on("click", async (event) => {
      const actionId = event.currentTarget.closest("[data-action-id]")?.dataset?.actionId;
      if (!actionId) return;

      const action = getCustomActions().find((a) => a.id === actionId);
      if (!action) return ui.notifications.error("Action not found.");

      const speaker = ChatMessage.getSpeaker();
      const actor = game.actors.get(speaker.actor);
      if (!actor) return ui.notifications.warn("No actor selected.");

      const success = await deductAP(actor, action.apCost);
      if (!success) {
        ui.notifications.warn("Not enough AP to perform this action.");
        return;
      }

      await logToHistory(actor, `Used custom action "${action.label}" from GM panel.`);
      Hooks.call("tickpoint-custom-action-used", actor, action);
      this.render();
    });

    html.find(".clear-history").on("click", async () => {
      if (!confirm("Clear the entire action history log? This cannot be undone.")) return;

      for (const actor of game.actors.contents) {
        await clearHistoryLog(actor);
      }

      ui.notifications.info("TickPoint Combat | Action history log cleared.");
      this.render();
    });

    html.find(".export-history").on("click", () => {
      const exportText = [];

      for (const actor of game.actors.contents) {
        exportText.push(`--- ${actor.name} ---`);
        exportText.push(exportHistory(actor, { forGM: true }));
        exportText.push("");
      }

      exportText.push("--- General Logs ---");
      exportText.push(exportHistory(null, { forGM: true }));

      const blob = new Blob([exportText.join("\n")], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "tickpoint-combat-action-logs.txt";
      a.click();
      URL.revokeObjectURL(url);
    });

    html.find(".restore-ap").on("click", async (event) => {
      const actorId = event.currentTarget.closest("[data-actor-id]")?.dataset?.actorId;
      if (!actorId) return;

      const actor = game.actors.get(actorId);
      if (!actor) return;

      const amount = parseInt(prompt("Restore how many AP?"), 10);
      if (isNaN(amount) || amount <= 0) return;

      await restoreAP(actor, amount);
      await logToHistory(actor, `Restored ${amount} AP via GM Panel.`);
      this.render();
    });

    html.find(".deduct-ap").on("click", async (event) => {
      const actorId = event.currentTarget.closest("[data-actor-id]")?.dataset?.actorId;
      if (!actorId) return;

      const actor = game.actors.get(actorId);
      if (!actor) return;

      const amount = parseInt(prompt("Deduct how many AP?"), 10);
      if (isNaN(amount) || amount <= 0) return;

      const success = await deductAP(actor, amount);
      if (!success) {
        ui.notifications.warn("Not enough AP to deduct.");
        return;
      }

      await logToHistory(actor, `Deducted ${amount} AP via GM Panel.`);
      this.render();
    });
  }

  _registerHook() {
    this._apHook = () => this.render();
    Hooks.on("tickpoint-ap-updated", this._apHook);
  }

  close(options) {
    if (this._apHook) {
      Hooks.off("tickpoint-ap-updated", this._apHook);
      this._apHook = null;
    }
    return super.close(options);
  }

  async render(force, options) {
    const rendered = await super.render(force, options);
    if (!this._apHook) {
      this._registerHook();
    }
    return rendered;
  }
}

/**
 * Initialize the GM Panel singleton on ready if user is GM.
 */
export function initializeGMPanel() {
  Hooks.once("ready", () => {
    if (!game.user.isGM) return;
    game.tickpoint = game.tickpoint || {};
    if (!game.tickpoint.gmPanel) {
      game.tickpoint.gmPanel = new GMPanel();
    }
  });
}
