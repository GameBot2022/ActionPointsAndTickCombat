// File: modules/tickpoint-combat/scripts/gm-panel.js

import { getTimestamp } from "./helpers.js";
import { logToHistory } from "./history-log.js";

const PANEL_ID = "tickpoint-custom-actions";

export function registerGMPanel() {
  Hooks.once("ready", () => {
    if (!game.user.isGM) return;

    // Add GM panel button
    const button = document.createElement("button");
    button.innerHTML = `<i class="fas fa-tools"></i> Actions`;
    button.classList.add("tickpoint-gm-panel-button");
    button.addEventListener("click", openCustomActionsPanel);

    const sidebar = document.querySelector("#ui-left .sidebar-tabs");
    if (sidebar) sidebar.appendChild(button);
  });
}

export function openCustomActionsPanel() {
  const panel = new CustomActionsPanel();
  panel.render(true);
}

class CustomActionsPanel extends Application {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      id: PANEL_ID,
      title: "Custom Actions Manager",
      template: "modules/tickpoint-combat/templates/custom-actions.html",
      width: 600,
      height: "auto",
      resizable: true,
    });
  }

  getData() {
    const actions = game.settings.get("tickpoint-combat", "customActions") || [];
    return {
      actions,
      timestamp: getTimestamp()
    };
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find(".add-action").on("click", this._onAddAction.bind(this));
    html.find(".delete-action").on("click", this._onDeleteAction.bind(this));
    html.find(".use-action").on("click", this._onUseAction.bind(this));
  }

  async _onAddAction(event) {
    const form = this.element.find("form")[0];
    const data = new FormData(form);
    const label = data.get("label");
    const apCost = Number(data.get("apCost"));
    const tickDelay = Number(data.get("tickDelay"));
    const category = data.get("category") || "General";
    const icon = data.get("icon") || "icons/svg/target.svg";

    if (!label) return ui.notifications.warn("Label is required.");

    const actions = game.settings.get("tickpoint-combat", "customActions") || [];
    actions.push({ label, apCost, tickDelay, category, icon });

    await game.settings.set("tickpoint-combat", "customActions", actions);
    this.render();
  }

  async _onDeleteAction(event) {
    const index = Number(event.currentTarget.dataset.index);
    let actions = game.settings.get("tickpoint-combat", "customActions") || [];
    actions.splice(index, 1);
    await game.settings.set("tickpoint-combat", "customActions", actions);
    this.render();
  }

  async _onUseAction(event) {
    const index = Number(event.currentTarget.dataset.index);
    const actions = game.settings.get("tickpoint-combat", "customActions") || [];
    const action = actions[index];
    if (!action) return;

    const speaker = ChatMessage.getSpeaker();
    const actor = game.actors.get(speaker.actor);
    if (!actor) return ui.notifications.warn("No actor selected.");

    Hooks.call("tickpoint-custom-action-used", actor, action);
    logToHistory(actor, `Used "${action.label}" from GM panel`);

    this.render();
  }

  import { getCustomActions, saveCustomAction, deleteCustomAction } from "./custom-actions.js";
  import { getActionHistory, clearHistory, exportHistory } from "./history-log.js";

  export function initializeGMPanel() {
    game.tickpoint.gmPanel = new GMPanel();
  }

  class GMPanel {
    constructor() {
      this.rendered = false;
    }

    async render(force = false) {
      if (this.rendered && !force) return;

      const customActions = getCustomActions();
      const history = getActionHistory();

      const html = await renderTemplate("modules/tickpoint-combat/templates/custom-actions.html", {
        customActions,
        history
      });

      if (!this.element) {
        this.element = document.createElement("div");
        this.element.classList.add("tickpoint-gm-panel");
        document.body.appendChild(this.element);
      }
      this.element.innerHTML = html;

      this._attachListeners();

      this.rendered = true;
    }

    _attachListeners() {
      // Add new action button
      this.element.querySelector(".add-action").addEventListener("click", async () => {
        const label = prompt("Enter new action label:");
        if (!label) return;
        const apCost = parseInt(prompt("Enter AP cost:"), 10) || 0;
        const icon = prompt("Enter icon class (e.g. fas fa-sword):") || "fas fa-question";
        const category = prompt("Enter category:") || "General";

        saveCustomAction({ id: crypto.randomUUID(), label, apCost, icon, category });
        this.render(true);
      });

      // Edit action buttons
      this.element.querySelectorAll(".edit-action").forEach(btn => {
        btn.addEventListener("click", () => {
          const tr = btn.closest("tr");
          const actionId = tr.dataset.actionId;
          const action = getCustomActions().find(a => a.id === actionId);
          if (!action) return;

          const label = prompt("Edit action label:", action.label);
          if (!label) return;
          const apCost = parseInt(prompt("Edit AP cost:", action.apCost), 10) || 0;
          const icon = prompt("Edit icon class:", action.icon) || "fas fa-question";
          const category = prompt("Edit category:", action.category) || "General";

          saveCustomAction({ ...action, label, apCost, icon, category });
          this.render(true);
        });
      });

      // Delete action buttons
      this.element.querySelectorAll(".delete-action").forEach(btn => {
        btn.addEventListener("click", () => {
          const tr = btn.closest("tr");
          const actionId = tr.dataset.actionId;
          if (confirm("Are you sure you want to delete this action?")) {
            deleteCustomAction(actionId);
            this.render(true);
          }
        });
      });

      // Clear history button (inside history container)
      this.element.querySelector(".clear-history")?.addEventListener("click", () => {
        if (confirm("Clear the action history log?")) {
          clearHistory();
          this.render(true);
        }
      });

      // Export history button
      this.element.querySelector(".export-history")?.addEventListener("click", () => {
        exportHistory();
      });
    }

    close() {
      if (this.element) this.element.remove();
      this.rendered = false;
    }
  }


}
