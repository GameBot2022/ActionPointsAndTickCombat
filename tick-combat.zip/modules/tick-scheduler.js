// File: modules/tickpoint-combat/scripts/tick-scheduler.js

import { getActorSpeedTicks } from "./ap-utils.js";
import { getModuleSetting as getSetting } from "./settings.js";
import { logToHistory } from "./history-log.js";
import { updateTickTrackerUI, animateTickProgress } from "./tick-tracker.js";
import { handleLongActionsTick } from "./long-action.js";

export class TickScheduler {
  constructor() {
    this.currentTick = 0;
    this.maxTicks = null; // will be initialized later
    this.tickDuration = null;
    this.intervalId = null;
    this.combat = null;
    this.ready = false;

    Hooks.once("ready", () => {
      this.maxTicks = getSetting("maxTicks") || 30;
      this.tickDuration = getSetting("tickDuration") || 1000;
      this.ready = true;
    });
  }

  /**
   * Initialize the scheduler for a combat encounter
   * @param {Combat} combat
   */
  initialize(combat) {
    if (!this.ready) {
      console.warn("TickPoint Combat | TickScheduler not ready yet. Delaying init.");
      Hooks.once("ready", () => this.initialize(combat));
      return;
    }

    this.combat = combat;
    this.maxTicks = getSetting("maxTicks") || 30;
    this.tickDuration = getSetting("tickDuration") || 1000;
    this.currentTick = 0;

    if (combat?.combatants?.size > 0 && combat.started) {
      this._start();
    } else {
      this.stop();
    }
  }

  _start() {
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = setInterval(() => this._processTick(), this.tickDuration);
  }

  /**
   * Stop the tick scheduler and reset UI
   */
  stop() {
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = null;
    this.currentTick = 0;
    updateTickTrackerUI(null);
  }

  /**
   * Advance one tick and handle round wrap and actions
   */
  _processTick() {
    if (!this.combat || !this.combat.combatants) return;

    this.currentTick++;

    if (this.currentTick > this.maxTicks) {
      this.currentTick = 1;
      this._onNewRound();
    }

    animateTickProgress(this.currentTick);
    this._refreshUI();
    this._handleEligibleTurns();
    handleLongActionsTick(this.currentTick);

    Hooks.call("tickpoint-tick-start", this.currentTick);
  }

  _onNewRound() {
    logToHistory(null, `New Round Started`);
    Hooks.call("tickpoint-new-round", this.combat, this.currentTick);
  }

  _refreshUI() {
    updateTickTrackerUI(this.currentTick);
  }

  _handleEligibleTurns() {
    if (!this.combat || !this.combat.combatants) return;

    for (let combatant of this.combat.combatants) {
      const actor = combatant.actor;
      if (!actor) continue;

      const ticks = getActorSpeedTicks(actor);
      if (Array.isArray(ticks) && ticks.includes(this.currentTick)) {
        this._processCombatantTurn(actor);
      }
    }
  }

  _processCombatantTurn(actor) {
    logToHistory(actor, `Eligible to act on Tick ${this.currentTick}`);
    Hooks.call("tickpoint-actor-eligible", actor, this.currentTick);
  }
}

export const TickSchedulerInstance = new TickScheduler();

// Foundry Hooks to manage combat lifecycle integration
Hooks.on("createCombat", combat => {
  if (!combat) return;
  TickSchedulerInstance.initialize(combat);
});

Hooks.on("deleteCombat", () => {
  TickSchedulerInstance.stop();
});

Hooks.on("updateCombat", (combat, changes) => {
  if (changes.round !== undefined || changes.started !== undefined) {
    TickSchedulerInstance.initialize(combat);
  }
});
