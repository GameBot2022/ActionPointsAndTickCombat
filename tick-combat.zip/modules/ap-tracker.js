// File: modules/tickpoint-combat/modules/ap-tracker.js

import { getMaxAP, getCurrentAP, setCurrentAP, getAPCostForAction } from "./ap-utils.js";
import { logToHistory } from "./history-log.js";
import { isCombatActive } from "./helpers.js";

export function initializeAPTracker() {
  // Initialize AP for all combatants when combat starts
  Hooks.on("createCombat", async (combat) => {
    for (let combatant of combat.combatants) {
      if (!combatant.actor) continue;
      await initializeAPForActor(combatant.actor);
    }
  });

  // Clear AP flags when combat ends or is deleted
  Hooks.on("deleteCombat", async (combat) => {
    for (let combatant of combat.combatants) {
      if (!combatant.actor) continue;
      await clearAPFlags(combatant.actor);
    }
  });

  // Reset AP on new round
  Hooks.on("updateCombat", async (combat, changed) => {
    if (changed.round !== undefined) {
      for (let combatant of combat.combatants) {
        const actor = combatant.actor;
        if (!actor) continue;
        const maxAP = getMaxAPSafe(actor);
        await setCurrentAP(actor, maxAP);
        Hooks.call("tickpoint-ap-updated", actor);
      }
    }
  });

  // Deduct AP when a custom action is used, log it, and update UI/hooks
  Hooks.on("tickpoint-custom-action-used", async (actor, action) => {
    if (!actor || !action) return;
    const currentAP = getCurrentAP(actor);
    const cost = getAPCostForAction(action, actor);
    if (currentAP < cost) {
      ui.notifications.warn("Not enough AP to perform this action.");
      return;
    }
    await setCurrentAP(actor, currentAP - cost);
    logToHistory(actor, `Used custom action: ${action.label} (-${cost} AP)`);
    Hooks.call("tickpoint-ap-updated", actor);
  });
}

/**
 * Initialize AP for a given actor: set max AP and current AP flags.
 * @param {Actor} actor
 */
export async function initializeAPForActor(actor) {
  const maxAP = getMaxAPSafe(actor);
  await actor.setFlag("tickpoint-combat", "maxAP", maxAP);
  await setCurrentAP(actor, maxAP);
  Hooks.call("tickpoint-ap-updated", actor);
}

/**
 * Clear AP-related flags from an actor.
 * @param {Actor} actor
 */
export async function clearAPFlags(actor) {
  await actor.unsetFlag("tickpoint-combat", "currentAP");
  await actor.unsetFlag("tickpoint-combat", "maxAP");
  Hooks.call("tickpoint-ap-updated", actor);
}

/**
 * Safely get Max AP from formulas, with fallback on errors.
 * @param {Actor} actor
 * @returns {number} max AP value
 */
function getMaxAPSafe(actor) {
  try {
    const maxAP = getMaxAP(actor);
    if (typeof maxAP !== "number" || isNaN(maxAP) || maxAP < 0) {
      throw new Error("Max AP formula returned invalid value");
    }
    return maxAP;
  } catch (e) {
    console.error("Error evaluating Max AP formula for actor", actor.name, e);
    return 0;
  }
}

/**
 * Deduct AP from an actor for a given cost.
 * @param {Actor} actor
 * @param {number} cost
 * @returns {Promise<boolean>} true if deduction succeeded, false if insufficient AP
 */
export async function deductAP(actor, cost) {
  if (typeof cost !== "number" || cost <= 0) return true; // No cost or invalid cost

  const currentAP = getCurrentAP(actor);
  if (currentAP < cost) return false;

  await setCurrentAP(actor, currentAP - cost);
  Hooks.call("tickpoint-ap-updated", actor);
  return true;
}

/**
 * Restore AP to an actor, up to their max AP.
 * @param {Actor} actor
 * @param {number} amount
 */
export async function restoreAP(actor, amount) {
  if (typeof amount !== "number" || amount <= 0) return;

  const currentAP = getCurrentAP(actor);
  const maxAP = getMaxAPSafe(actor);
  const newAP = Math.min(currentAP + amount, maxAP);

  await setCurrentAP(actor, newAP);
  Hooks.call("tickpoint-ap-updated", actor);
}

/**
 * Validate current AP on an actor, correcting if out of bounds.
 * @param {Actor} actor
 */
export async function validateAP(actor) {
  const currentAP = getCurrentAP(actor);
  const maxAP = getMaxAPSafe(actor);

  let correctedAP = currentAP;
  if (currentAP > maxAP) correctedAP = maxAP;
  if (currentAP < 0) correctedAP = 0;

  if (correctedAP !== currentAP) {
    await setCurrentAP(actor, correctedAP);
    Hooks.call("tickpoint-ap-updated", actor);
  }
}
