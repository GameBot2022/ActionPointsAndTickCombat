// File: modules/tickpoint-combat/scripts/history-log.js

/**
 * Logs action history entries for actors, with visibility control.
 * Stores logs as actor flags and optionally persists across sessions.
 */

const MAX_HISTORY_LENGTH = 100;

/**
 * Log a message entry for a specific actor.
 * If actor is null, logs a general system message (stored globally).
 * @param {Actor|null} actor - The actor to log for, or null for general/system messages.
 * @param {string} message - The log message.
 * @param {Object} options - Optional settings:
 *   - {boolean} visibleToPlayers - If false, only GMs see this log entry (default true).
 */
export async function logToHistory(actor, message, options = {}) {
  const visibleToPlayers = options.visibleToPlayers ?? true;
  const timestamp = getTimestamp();
  const entry = {
    timestamp,
    message,
    visibleToPlayers,
  };

  if (actor) {
    let history = actor.getFlag("tickpoint-combat", "historyLog") || [];
    history.push(entry);
    if (history.length > MAX_HISTORY_LENGTH) {
      history = history.slice(history.length - MAX_HISTORY_LENGTH);
    }
    await actor.setFlag("tickpoint-combat", "historyLog", history);
    Hooks.call("tickpoint-history-updated", actor, history);
  } else {
    let generalHistory = game.settings.get("tickpoint-combat", "generalHistoryLog") || [];
    generalHistory.push(entry);
    if (generalHistory.length > MAX_HISTORY_LENGTH) {
      generalHistory = generalHistory.slice(generalHistory.length - MAX_HISTORY_LENGTH);
    }
    await game.settings.set("tickpoint-combat", "generalHistoryLog", generalHistory);
    Hooks.call("tickpoint-general-history-updated", generalHistory);
  }
}

/**
 * Retrieve the history log entries for an actor.
 * Optionally filter by visibility (e.g., only GM-visible).
 * If actor is null, returns general/system logs.
 * @param {Actor|null} actor
 * @param {Object} options
 *   - {boolean} forGM - If true, returns all logs; else filters by visibleToPlayers=true.
 * @returns {Array} Array of log entries.
 */
export function getHistoryLog(actor, options = {}) {
  const forGM = options.forGM ?? false;
  if (actor) {
    const history = actor.getFlag("tickpoint-combat", "historyLog") || [];
    return forGM ? history : history.filter(entry => entry.visibleToPlayers !== false);
  } else {
    const generalHistory = game.settings.get("tickpoint-combat", "generalHistoryLog") || [];
    return forGM ? generalHistory : generalHistory.filter(entry => entry.visibleToPlayers !== false);
  }
}

/**
 * Clear the entire history log for an actor.
 * If actor is null, clears the general/system log.
 * @param {Actor|null} actor
 */
export async function clearHistoryLog(actor) {
  if (actor) {
    await actor.unsetFlag("tickpoint-combat", "historyLog");
    Hooks.call("tickpoint-history-cleared", actor);
  } else {
    await game.settings.set("tickpoint-combat", "generalHistoryLog", []);
    Hooks.call("tickpoint-general-history-cleared");
  }
}

/**
 * Clear history logs for all combatants in a combat.
 * @param {Combat} combat
 */
export async function clearHistoryForCombatants(combat) {
  if (!combat) return;
  for (const combatant of combat.combatants) {
    if (combatant.actor) {
      await clearHistoryLog(combatant.actor);
    }
  }
}

/**
 * Get a formatted string representation of the history log entries,
 * for display in a UI panel or console.
 * @param {Array} historyEntries
 * @returns {string}
 */
export function formatHistoryEntries(historyEntries) {
  return historyEntries.map(entry => `[${entry.timestamp}] ${entry.message}`).join("\n");
}

/**
 * Export the full history log as a formatted string,
 * either for a specific actor or the general log.
 * @param {Actor|null} actor - If null, exports general/system log.
 * @param {Object} options - Optional settings:
 *   - {boolean} forGM - If true, includes GM-only entries.
 * @returns {string}
 */
export function exportHistory(actor = null, options = {}) {
  const history = getHistoryLog(actor, options);
  return formatHistoryEntries(history);
}

/**
 * Get current timestamp formatted string.
 * @returns {string}
 */
function getTimestamp() {
  const now = new Date();
  const pad = (n) => n.toString().padStart(2, "0");
  const year = now.getFullYear();
  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());
  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * Hook example usage for auto-refresh UI when history updates:
 * Hooks.on("tickpoint-history-updated", (actor, history) => {
 *   // Refresh your module UI here for actor-specific logs
 * });
 * Hooks.on("tickpoint-general-history-updated", (history) => {
 *   // Refresh your module UI here for general logs
 * });
 */
