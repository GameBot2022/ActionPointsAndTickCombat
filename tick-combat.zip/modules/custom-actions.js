// File: modules/tickpoint-combat/scripts/custom-actions.js

import { getModuleSetting, setModuleSetting } from "./settings.js";
import { logToHistory } from "./history-log.js";
import { getAPCostForAction } from "./ap-utils.js";
import { getCurrentAP, setCurrentAP } from "./ap-utils.js";

/** Setting key for custom actions */
const CUSTOM_ACTIONS_SETTING = "customActions";

/**
 * Get all custom actions stored in settings.
 * @returns {Array<Object>}
 */
export function getCustomActions() {
  return getModuleSetting(CUSTOM_ACTIONS_SETTING) || [];
}

/**
 * Save a list of custom actions to settings and trigger update hooks.
 * @param {Array<Object>} actions
 */
export async function setCustomActions(actions) {
  await setModuleSetting(CUSTOM_ACTIONS_SETTING, actions);
  Hooks.call("tickpoint-custom-actions-updated", actions);
}

/**
 * Add a new custom action.
 * @param {Object} action - The new custom action object.
 * @returns {Object} - The added action with generated ID and timestamp.
 */
export async function addCustomAction(action) {
  const actions = getCustomActions();
  const newAction = {
    ...action,
    id: action.id || randomID(),
    createdAt: Date.now(),
  };
  actions.push(newAction);
  await setCustomActions(actions);
  return newAction;
}

/**
 * Remove a custom action by ID.
 * @param {string} id - The unique ID of the action.
 */
export async function removeCustomAction(id) {
  const actions = getCustomActions().filter(a => a.id !== id);
  await setCustomActions(actions);
}

/**
 * Update a custom action by ID.
 * @param {string} id - The action's unique ID.
 * @param {Object} updates - Partial updates to the action object.
 */
export async function updateCustomAction(id, updates) {
  const actions = getCustomActions().map(a => (a.id === id ? { ...a, ...updates } : a));
  await setCustomActions(actions);
}

/**
 * Retrieve a custom action by ID.
 * @param {string} id
 * @returns {Object|null}
 */
export function getCustomActionById(id) {
  return getCustomActions().find(a => a.id === id) || null;
}

/**
 * Get AP cost for a given action ID and actor.
 * Evaluates cost formula if available.
 * @param {string} id
 * @param {Actor|null} actor
 * @returns {number|null}
 */
export function getAPCostForActionById(id, actor = null) {
  const action = getCustomActionById(id);
  if (!action) return null;
  return getAPCostForAction(action, actor);
}

/**
 * Perform a custom action for an actor: deducts AP, logs it, and fires hooks.
 * @param {Actor} actor
 * @param {string} actionId
 * @returns {Promise<boolean>} true if action succeeded, false otherwise
 */
export async function performCustomAction(actor, actionId) {
  if (!actor) {
    ui.notifications.error("No actor selected.");
    return false;
  }

  const action = getCustomActionById(actionId);
  if (!action) {
    ui.notifications.error("Custom action not found.");
    return false;
  }

  const cost = getAPCostForAction(action, actor);
  const currentAP = getCurrentAP(actor);

  if (currentAP < cost) {
    ui.notifications.warn(`Not enough AP to perform "${action.label ?? action.name}".`);
    return false;
  }

  await setCurrentAP(actor, currentAP - cost);
  await logToHistory(
    actor,
    `Performed custom action: ${action.label ?? action.name} (-${cost} AP)`,
    { visibleToPlayers: true }
  );

  Hooks.call("tickpoint-custom-action-performed", actor, action);
  Hooks.call("tickpoint-ap-updated", actor);

  return true;
}

/**
 * Filter actions by category.
 * @param {string|null} category
 * @returns {Array<Object>}
 */
export function getActionsByCategory(category = null) {
  const actions = getCustomActions();
  return category ? actions.filter(a => a.category === category) : actions;
}

/**
 * Initialize listeners for live UI updates when custom actions are changed.
 */
export function initializeCustomActions() {
  Hooks.on("tickpoint-custom-actions-updated", (actions) => {
    console.log("TickPoint Combat | Custom actions updated:", actions);
    // Other modules may hook into this to update UI panels
  });
}
