// File: modules/tickpoint-combat/scripts/settings.js

/**
 * Dialog class to clear the action history log.
 */
class ResetLogDialog extends FormApplication {
  constructor(options = {}) {
    super({}, options);
  }

  /** No UI fields needed, just clear the log on submit */
  async _updateObject(event, formData) {
    await game.settings.set("tickpoint-combat", "actionHistoryLog", []);
    ui.notifications.info("TickPoint Combat: Action history log cleared.");
  }

  /** Minimal UI - just confirmation */
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      title: "Clear Action History Log",
      template: "modules/tickpoint-combat/templates/reset-log-dialog.html",
      width: 400,
      height: "auto",
      closeOnSubmit: true,
      submitOnChange: false,
      resizable: false,
    });
  }
}

/**
 * Register all module settings used across TickPoint Combat.
 */
export function registerSettings() {
  // Speed formula - used to calculate actor speed dynamically
  game.settings.register("tickpoint-combat", "speedFormula", {
    name: "Speed Formula",
    hint:
      "JavaScript expression to calculate speed (e.g., (DEX + SIZ + INT) / 3). Use DEX, SIZ, INT as variables.",
    scope: "world",
    config: true,
    default: "(DEX + SIZ + INT) / 3",
    type: String,
  });

  // Max AP formula - determines max action points for an actor
  game.settings.register("tickpoint-combat", "maxAPFormula", {
    name: "Max AP Formula",
    hint:
      "JavaScript expression to calculate max AP (e.g., Math.floor(getActorSpeedTicks(actor) * 2)). Use actor and getActorSpeedTicks in formula.",
    scope: "world",
    config: true,
    default: "Math.floor(getActorSpeedTicks(actor) * 2)",
    type: String,
  });

  // Toggle AP tracking outside of combat
  game.settings.register("tickpoint-combat", "enableAPOutsideCombat", {
    name: "Enable AP Tracking Outside Combat",
    hint: "Allows AP tracking to continue even when not in combat.",
    scope: "world",
    config: true,
    default: false,
    type: Boolean,
  });

  // Default max AP fallback if formula evaluation fails
  game.settings.register("tickpoint-combat", "defaultMaxAP", {
    name: "Default Max AP",
    hint: "Fallback max AP value used if formula evaluation fails.",
    scope: "world",
    config: true,
    default: 5,
    type: Number,
  });

  // Tick duration in milliseconds
  game.settings.register("tickpoint-combat", "tickDuration", {
    name: "Tick Duration (ms)",
    hint: "Milliseconds between ticks (e.g., 1000 = 1 second).",
    scope: "world",
    config: true,
    default: 1000,
    type: Number,
  });

  // Maximum number of ticks allowed per round
  game.settings.register("tickpoint-combat", "maxTicks", {
    name: "Max Ticks Per Round",
    hint: "Maximum number of ticks per combat round.",
    scope: "world",
    config: true,
    default: 30,
    type: Number,
  });

  // Show/hide the quick action panel (client scope)
  game.settings.register("tickpoint-combat", "showQuickActionPanel", {
    name: "Show Quick Action Panel",
    hint: "Toggles visibility of the quick-action UI for players.",
    scope: "client",
    config: true,
    default: true,
    type: Boolean,
    onChange: () => window.location.reload(),
  });

  // Show/hide the GM panel (client scope)
  game.settings.register("tickpoint-combat", "showGMPanel", {
    name: "Show GM Panel",
    hint: "Toggles visibility of the GM panel for GMs.",
    scope: "client",
    config: true,
    default: true,
    type: Boolean,
    onChange: () => window.location.reload(),
  });

  // Storage for GM-configured custom actions (world scope, hidden from config)
  game.settings.register("tickpoint-combat", "customActions", {
    name: "Custom Actions (GM)",
    scope: "world",
    config: false,
    default: [],
    type: Array,
  });

  // Persistent log of actions, stored globally
  game.settings.register("tickpoint-combat", "actionHistoryLog", {
    name: "Persistent Action History Log",
    scope: "world",
    config: false,
    default: [],
    type: Array,
  });

  // Menu entry to clear the action history log, restricted to GMs
  game.settings.registerMenu("tickpoint-combat", "resetLog", {
    name: "Clear Action History Log",
    label: "Clear Log",
    hint: "Delete all entries in the persistent action history.",
    icon: "fas fa-trash",
    type: ResetLogDialog,
    restricted: true,
  });
}

/**
 * Standard getter for module settings.
 * @param {string} key
 * @returns {*}
 */
export function getModuleSetting(key) {
  return game.settings.get("tickpoint-combat", key);
}

/**
 * Standard setter for module settings.
 * @param {string} key
 * @param {*} value
 * @returns {Promise<void>}
 */
export async function setModuleSetting(key, value) {
  return await game.settings.set("tickpoint-combat", key, value);
}
