// File: modules/tickpoint-combat/scripts/long-action.js

import { logToHistory } from "./history-log.js";
import { getCurrentAP, setCurrentAP } from "./ap-utils.js";
import { isCombatActive } from "./helpers.js";

const longActions = new Map(); // actorId => { ticksRemaining, label, apCost }

/**
 * Register hooks for long action system lifecycle
 */
export function initializeLongActions() {
  Hooks.on("tickpoint-tick-start", handleLongActionsTick);
  Hooks.on("deleteCombat", () => longActions.clear());
  Hooks.on("deleteActor", actor => longActions.delete(actor.id));

  // Instantiate UI controller singleton
  game.tickpoint = game.tickpoint || {};
  game.tickpoint.longAction = new LongAction();
}

/**
 * Start a long action for an actor with given parameters.
 * Deduct AP cost immediately.
 * @param {Actor} actor
 * @param {Object} options - {label:string, ticks:number, apCost:number}
 */
export function startLongAction(actor, { label = "Long Action", ticks = 3, apCost = 0 } = {}) {
  if (!actor) return;

  const currentAP = getCurrentAP(actor);
  if (currentAP < apCost) {
    ui.notifications.warn("Not enough AP to start long action.");
    return;
  }

  setCurrentAP(actor, currentAP - apCost);
  logToHistory(actor, `Started long action "${label}" (${ticks} ticks)`);
  longActions.set(actor.id, { ticksRemaining: ticks, label, apCost });

  Hooks.call("tickpoint-long-action-start", actor, { label, ticks, apCost });
  Hooks.call("tickpoint-ap-updated", actor);
}

/**
 * Handle tick events from the scheduler, decrement long action timers,
 * fire progress and completion hooks.
 * @param {number} currentTick
 */
export function handleLongActionsTick(currentTick) {
  if (!isCombatActive()) return;

  for (let [actorId, action] of longActions.entries()) {
    const actor = game.actors.get(actorId);
    if (!actor) {
      longActions.delete(actorId);
      continue;
    }

    action.ticksRemaining--;

    Hooks.call("tickpoint-long-action-progress", actor, action);

    if (action.ticksRemaining <= 0) {
      completeLongAction(actor, action);
    }
  }
}

/**
 * Complete a long action, remove from map, notify hooks and log.
 * @param {Actor} actor
 * @param {Object} action
 */
function completeLongAction(actor, action) {
  if (!actor) return;
  logToHistory(actor, `Completed long action "${action.label}"`);
  longActions.delete(actor.id);
  Hooks.call("tickpoint-long-action-complete", actor, action);
}

/**
 * UI class managing rendering and interaction of long action progress display.
 */
class LongAction {
  constructor() {
    this.rendered = false;
    this.element = null;
  }

  /**
   * Render or update the long action progress UI.
   * @param {number} progress - Current progress percentage (0-100)
   * @param {string} actionLabel - Label of the ongoing action
   * @param {boolean} canCancel - Whether the action can be cancelled
   */
  async render(progress = 0, actionLabel = "", canCancel = true) {
    const html = await renderTemplate("modules/tickpoint-combat/templates/long-action.html", {
      progress,
      actionLabel,
      canCancel
    });

    if (!this.element) {
      this.element = document.createElement("div");
      this.element.classList.add("tickpoint-long-action");
      document.body.appendChild(this.element);
    }
    this.element.innerHTML = html;

    this._attachListeners();

    this.rendered = true;
  }

  _attachListeners() {
    this.element.querySelector(".cancel-action")?.addEventListener("click", () => {
      // Emit hook that long action was cancelled
      Hooks.call("tickpoint-long-action-cancelled");
      this.close();
    });
  }

  close() {
    if (this.element) {
      this.element.remove();
      this.element = null;
    }
    this.rendered = false;
  }
}
