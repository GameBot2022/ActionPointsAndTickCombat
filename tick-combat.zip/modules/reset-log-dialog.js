// File: modules/tickpoint-combat/modules/reset-log-dialog.js

import { clearHistoryLog } from "./history-log.js";

export class ResetLogDialog extends FormApplication {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      id: "reset-log-dialog",
      title: "Reset Action History Log",
      template: "modules/tickpoint-combat/templates/reset-log-dialog.html",
      width: 400,
      height: "auto",
      closeOnSubmit: true,
      resizable: false,
      classes: ["tickpoint", "dialog"],
    });
  }

  /** @override */
  getData() {
    return {}; // No dynamic data needed for now
  }

  /** @override */
  async _updateObject(_event, _formData) {
    // Clear history log for all actors
    for (const actor of game.actors.contents) {
      await clearHistoryLog(actor);
    }

    ui.notifications.info("TickPoint Combat | Action history log has been reset.");
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);

    // Cancel button manually dispatches close event
    html.find("button[data-action='cancel']").on("click", (ev) => {
      ev.preventDefault();
      this.close();
    });

    // Escape key support for closing dialog
    // Use jQuery event delegation attached to the dialog root element
    html.on("keydown", (ev) => {
      if (ev.key === "Escape") {
        ev.preventDefault();
        this.close();
      }
    });
  }
}
