// File: modules/tickpoint-combat/scripts/quick-actions-panel.js

import { getCustomActions } from "./custom-actions.js";
import { getCurrentAP, deductAP, restoreAP } from "./ap-utils.js";
import { useQuickAction } from "./quick-actions.js";

export class QuickActionsPanel {
  constructor() {
    this.rendered = false;
    this.element = null;
    this._onAPUpdated = this._onAPUpdated.bind(this);
    Hooks.on("tickpoint-ap-updated", this._onAPUpdated);
  }

  /**
   * Render or re-render the quick actions UI.
   * @param {boolean} force - Force re-render even if already rendered.
   */
  async render(force = false) {
    if (this.rendered && !force) return;

    const actions = getCustomActions();
    const actor = canvas.tokens.controlled[0]?.actor;
    const currentAP = actor ? getCurrentAP(actor) : 0;

    // Render the Handlebars template for the quick actions panel
    const html = await renderTemplate("modules/tickpoint-combat/templates/quick-actions.html", {
      actions,
      currentAP,
      actorName: actor?.name || "",
    });

    if (!this.element) {
      this.element = document.createElement("div");
      this.element.classList.add("tickpoint-quick-actions");
      document.body.appendChild(this.element);
    }

    this.element.innerHTML = html;
    this._attachListeners();

    this.rendered = true;
  }

  /**
   * Re-render on AP changes to keep UI in sync.
   * @param {Actor} actor - Actor whose AP was updated.
   */
  async _onAPUpdated(actor) {
    // Only re-render if the currently controlled token's actor AP changed
    const currentActor = canvas.tokens.controlled[0]?.actor;
    if (currentActor && actor?.id === currentActor.id) {
      await this.render(true);
    }
  }

  /**
   * Attach event listeners to the rendered UI elements.
   */
  _attachListeners() {
    if (!this.element) return;

    // Quick action button click handlers
    this.element.querySelectorAll(".quick-action-button").forEach(button => {
      button.addEventListener("click", async () => {
        const actionId = button.dataset.actionId;
        const actor = canvas.tokens.controlled[0]?.actor;

        if (!actor) {
          ui.notifications.warn("Select a token first.");
          return;
        }

        const action = getCustomActions().find(a => a.id === actionId);
        if (!action) return;

        // Use the action with AP deduction handled by useQuickAction()
        const used = await useQuickAction(actor, action);
        if (used) {
          await this.render(true); // Update UI after AP changes
        }
      });
    });

    // AP restore buttons
    this.element.querySelectorAll(".ap-restore-button").forEach(button => {
      button.addEventListener("click", async () => {
        const actor = canvas.tokens.controlled[0]?.actor;
        if (!actor) {
          ui.notifications.warn("Select a token first.");
          return;
        }

        const amount = Number(button.dataset.amount) || 1;
        await restoreAP(actor, amount);
        await this.render(true);
      });
    });

    // AP deduct buttons
    this.element.querySelectorAll(".ap-deduct-button").forEach(button => {
      button.addEventListener("click", async () => {
        const actor = canvas.tokens.controlled[0]?.actor;
        if (!actor) {
          ui.notifications.warn("Select a token first.");
          return;
        }

        const amount = Number(button.dataset.amount) || 1;
        const success = await deductAP(actor, amount);
        if (!success) {
          ui.notifications.warn("Not enough AP to deduct.");
          return;
        }

        await this.render(true);
      });
    });
  }

  /**
   * Remove the UI panel from the DOM and clean up hooks.
   */
  close() {
    if (this.element) {
      this.element.remove();
      this.element = null;
    }
    this.rendered = false;
    Hooks.off("tickpoint-ap-updated", this._onAPUpdated);
  }
}
