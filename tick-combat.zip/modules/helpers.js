// File: modules/tickpoint-combat/scripts/helpers.js

/**
 * Check if combat is currently active.
 * @returns {boolean} true if combat is active and not ended.
 */
export function isCombatActive() {
  const combat = game.combat;
  if (!combat) return false;
  if (combat.round === 0 || combat.started === false) return false;
  return !combat.combatants.every(c => c.defeated);
}

/**
 * Return a formatted timestamp string for current date/time.
 * Format: YYYY-MM-DD HH:mm:ss
 * @returns {string}
 */
export function getTimestamp() {
  const now = new Date();
  const pad = (n) => n.toString().padStart(2, "0");
  const year = now.getFullYear();
  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());
  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * Safely parse a formula string for an actor, evaluating it in context.
 * Falls back to defaultValue on error or invalid result.
 * @param {string} formula - The formula string to evaluate
 * @param {Actor} actor - The actor context for the formula
 * @param {number} defaultValue - The fallback value if formula fails
 * @returns {number} - Evaluated number or defaultValue
 */
export function safeEvaluateFormula(formula, actor, defaultValue = 0) {
  if (!formula || typeof formula !== "string") return defaultValue;
  try {
    // Use Foundry's Roll formula parser with actor data context
    const roll = new Roll(formula, actor.getRollData());
    const result = roll.evaluate({ async: false }).total;
    if (typeof result !== "number" || isNaN(result)) return defaultValue;
    return result;
  } catch (err) {
    console.error(`Error evaluating formula "${formula}" for actor ${actor.name}`, err);
    return defaultValue;
  }
}

/**
 * Utility to debounce calls to a function by a delay in ms.
 * @param {Function} func - Function to debounce
 * @param {number} wait - Delay in milliseconds
 * @returns {Function} - Debounced function
 */
export function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

/**
 * Capitalize the first letter of a string.
 * @param {string} str
 * @returns {string}
 */
export function capitalize(str) {
  if (typeof str !== "string") return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}
