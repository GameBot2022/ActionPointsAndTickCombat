// File: modules/tickpoint-combat/scripts/tick-tracker.js

import { getActorSpeedTicks } from "./ap-utils.js";
import { getModuleSetting as getSetting } from "./settings.js";

let tickTrackerElement = null;
let currentTick = 0;

/**
 * Create and attach the tick tracker UI to the DOM
 * @param {number} maxTicks - Maximum number of ticks per round
 */
export function renderTickTrackerUI(maxTicks = 30) {
  if (tickTrackerElement) tickTrackerElement.remove();

  tickTrackerElement = document.createElement("div");
  tickTrackerElement.id = "tickpoint-combat-tick-tracker";
  tickTrackerElement.classList.add("tick-tracker");

  for (let i = 1; i <= maxTicks; i++) {
    const tick = document.createElement("div");
    tick.classList.add("tick");
    tick.dataset.tick = i;

    const fill = document.createElement("div");
    fill.classList.add("tick-fill");
    tick.appendChild(fill);

    const label = document.createElement("span");
    label.classList.add("tick-label");
    label.innerText = i;
    tick.appendChild(label);

    tickTrackerElement.appendChild(tick);
  }

  document.body.appendChild(tickTrackerElement);
}

/**
 * Animate the tick fill bar to indicate progression
 * @param {number} tick - The current tick number
 */
export function animateTickProgress(tick) {
  currentTick = tick;
  const ticks = tickTrackerElement?.querySelectorAll(".tick");
  if (!ticks) return;

  ticks.forEach(t => {
    const fill = t.querySelector(".tick-fill");
    const tickNum = parseInt(t.dataset.tick);
    if (fill) {
      fill.style.width = tickNum <= tick ? "100%" : "0%";
    }
    t.classList.toggle("active", tickNum === tick);
  });
}

/**
 * Display actor icons on the ticks they are scheduled to act
 * @param {number|null} current - Current tick number to highlight
 */
export function updateTickTrackerUI(current) {
  const maxTicks = getSetting("maxTicks") || 30;
  if (!tickTrackerElement) renderTickTrackerUI(maxTicks);

  const combat = game.combat;
  if (!combat) return;

  const ticks = tickTrackerElement.querySelectorAll(".tick");
  // Remove all existing actor icons
  ticks.forEach(tick => tick.querySelectorAll(".actor-icon").forEach(el => el.remove()));

  for (const combatant of combat.combatants) {
    const actor = combatant.actor;
    if (!actor) continue;

    const ticksToAct = getActorSpeedTicks(actor);
    if (!Array.isArray(ticksToAct)) continue;

    for (const tickNumber of ticksToAct) {
      const tickEl = tickTrackerElement.querySelector(`.tick[data-tick="${tickNumber}"]`);
      if (!tickEl) continue;

      const icon = document.createElement("img");
      icon.src = actor.img || "icons/svg/mystery-man.svg";
      icon.alt = actor.name || "Actor";
      icon.title = actor.name || "Actor";
      icon.classList.add("actor-icon");
      icon.draggable = false;
      icon.style.width = "18px";
      icon.style.height = "18px";
      icon.style.borderRadius = "50%";
      icon.style.margin = "0 1px";

      tickEl.appendChild(icon);
    }
  }

  animateTickProgress(current);
}

/**
 * Clean up the tick tracker UI
 */
export function destroyTickTrackerUI() {
  if (tickTrackerElement) {
    tickTrackerElement.remove();
    tickTrackerElement = null;
  }
}
