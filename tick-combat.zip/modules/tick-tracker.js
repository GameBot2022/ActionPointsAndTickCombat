// File: modules/tickpoint-combat/scripts/tick-tracker.js

import { getActorSpeedTicks } from "./ap-utils.js";
import { getSetting } from "./settings.js";

let tickTrackerElement = null;
let currentTick = 0;

/**
 * Create and attach the tick tracker UI to the DOM
 */
export function renderTickTrackerUI(maxTicks = 30) {
  if (tickTrackerElement) tickTrackerElement.remove();

  tickTrackerElement = document.createElement("div");
  tickTrackerElement.classList.add("tick-tracker");

  for (let i = 1; i <= maxTicks; i++) {
    const tick = document.createElement("div");
    tick.classList.add("tick");
    tick.dataset.tick = i;

    const fill = document.createElement("div");
    fill.classList.add("tick-fill");
    tick.appendChild(fill);

    const label = document.createElement("span");
    label.classList.add("tick-label");
    label.innerText = i;
    tick.appendChild(label);

    tickTrackerElement.appendChild(tick);
  }

  document.body.appendChild(tickTrackerElement);
}

/**
 * Animate the tick fill bar to indicate progression
 */
export function animateTickProgress(tick) {
  currentTick = tick;
  const ticks = tickTrackerElement?.querySelectorAll(".tick");
  if (!ticks) return;

  ticks.forEach(t => {
    const fill = t.querySelector(".tick-fill");
    const tickNum = parseInt(t.dataset.tick);
    if (fill) {
      fill.style.width = tickNum <= tick ? "100%" : "0%";
    }

    t.classList.toggle("active", tickNum === tick);
  });
}

/**
 * Display actor icons on the ticks they are scheduled to act
 */
export function updateTickTrackerUI(current) {
  const maxTicks = getSetting("maxTicks") || 30;
  if (!tickTrackerElement) renderTickTrackerUI(maxTicks);

  const combat = game.combat;
  if (!combat) return;

  const ticks = tickTrackerElement.querySelectorAll(".tick");
  ticks.forEach(tick => tick.querySelectorAll(".actor-icon").forEach(el => el.remove()));

  for (let combatant of combat.combatants) {
    const actor = combatant.actor;
    if (!actor) continue;

    const ticksToAct = getActorSpeedTicks(actor);
    for (let tickNumber of ticksToAct) {
      const tickEl = tickTrackerElement.querySelector(`.tick[data-tick="${tickNumber}"]`);
      if (!tickEl) continue;

      const icon = document.createElement("img");
      icon.src = actor.img;
      icon.alt = actor.name;
      icon.title = actor.name;
      icon.classList.add("actor-icon");

      tickEl.appendChild(icon);
    }
  }

  animateTickProgress(current);
}
