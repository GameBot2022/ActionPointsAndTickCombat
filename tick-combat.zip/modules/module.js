// File: modules/tickpoint-combat/module.js

import { registerSettings } from "./settings.js";
import { initializeAPTracker } from "modules/tickpoint-combat/modules/ap-tracker.js";
import { initializeTickScheduler } from "modules/tickpoint-combat/modules/tick-scheduler.js";
import { initializeQuickActionsUI } from "modules/tickpoint-combat/modules/quick-actions.js";
import { initializeLongActions } from "modules/tickpoint-combat/modules/long-action.js";
import { initializeGMPanel } from "modules/tickpoint-combat/modules/gm-panel.js";
import { initializeCustomActions } from "modules/tickpoint-combat/modules/custom-actions.js";
import { initializeTickTrackerUI } from "modules/tickpoint-combat/modules/tick-tracker.js";
import { clearTemporaryUIElements, confirmDeleteLogs } from "./scripts/cleanup.js";

// Register module stylesheet
function registerStyles() {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "modules/tickpoint-combat/styles/tickpoint.css";
  document.head.appendChild(link);
}

// Preload templates
await loadTemplates([
  "modules/tickpoint-combat/templates/quick-actions.html",
  "modules/tickpoint-combat/templates/custom-actions.html",
  "modules/tickpoint-combat/templates/history-log.html",
  "modules/tickpoint-combat/templates/tick-tracker.html",
  "modules/tickpoint-combat/templates/long-action.html"
 ]);

Hooks.once("init", async function () {
  console.log("TickPoint Combat | Initializing module...");
  registerSettings();
  registerStyles();
});

Hooks.once("ready", async function () {
  console.log("TickPoint Combat | Initializing subsystems...");
  initializeAPTracker();
  initializeTickScheduler();
  initializeQuickActionsUI();
  initializeLongActions();
  initializeGMPanel();
  initializeCustomActions();
  initializeTickTrackerUI();

  if (game.user.isGM) {
    injectGMHistorySidebarButton();
  }
});

Hooks.on("shutdown", async function () {
  console.log("TickPoint Combat | Cleaning up module flags and UI...");
  for (let actor of game.actors.contents) {
    if (actor?.getFlag("tickpoint-combat", "currentAP")) {
      await actor.unsetFlag("tickpoint-combat", "currentAP");
      await actor.unsetFlag("tickpoint-combat", "maxAP");
    }
  }

  clearTemporaryUIElements();

  if (game.user.isGM) {
    const confirm = await confirmDeleteLogs();
    if (confirm) {
      await game.settings.set("tickpoint-combat", "actionHistoryLog", []);
      ui.notifications.info("TickPoint | Logs deleted.");
    }
  }
});

// Adds GM-only button to access custom actions/history log
function injectGMHistorySidebarButton() {
  Hooks.on("renderSidebarTab", (app, html) => {
    if (app.options.id !== "chat" || !game.user.isGM) return;

    const button = $(
      `<button class="tickpoint-history-log-button">
        <i class="fas fa-clipboard-list"></i> TickPoint Log
      </button>`
    );
    button.on("click", () => {
      game.tickpoint?.gmPanel?.render(true);
    });

    const controlArea = html.find(".directory-footer");
    controlArea.append(button);
  });

 // Hooks to show/hide UI panels based on settings
  Hooks.on("renderSceneControls", (controls) => {
    if (getSetting("showQuickActionsPanel")) {
      game.tickpoint.quickActions?.render(true);
    } else {
      game.tickpoint.quickActions?.close();
    }
    if (getSetting("showGMPanel")) {
      game.tickpoint.gmPanel?.render(true);
    } else {
      game.tickpoint.gmPanel?.close();
    }
  });

}
