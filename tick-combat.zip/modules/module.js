import { registerSettings, getModuleSetting } from "./settings.js";
import { initializeAPTracker } from "./ap-tracker.js";
import { TickSchedulerInstance } from "./tick-scheduler.js";
import { initializeQuickActions } from "./quick-actions.js";
import { initializeLongActions } from "./long-action.js";
import { initializeGMPanel, GMPanel } from "./gm-panel.js";
import { initializeCustomActions } from "./custom-actions.js";
import {
  initializeTickTrackerUI,
  updateTickTrackerUI,
  destroyTickTrackerUI,
} from "./tick-tracker.js";
import { clearTemporaryUIElements, confirmDeleteLogs } from "./cleanup.js";
import { CustomActionsPanel } from "./custom-actions-panel.js";
import { QuickActionsPanel } from "./quick-actions-panel.js";

/**
 * Register module stylesheet
 */
function registerStyles() {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "styles/tickpoint-combat.css";
  document.head.appendChild(link);
}

/**
 * Preload all required Handlebars templates
 */
await loadTemplates([
  "templates/quick-actions.html",
  "templates/custom-actions.html",
  "templates/history-log.html",
  "templates/tick-tracker.html",
  "templates/long-action.html",
  "templates/reset-log-dialog.html",
  "templates/custom-actions-panel.html",
  "templates/gm-panel.html",
]);

/**
 * Module initialization hook
 */
Hooks.once("init", async function () {
  console.log("TickPoint Combat | Initializing module...");
  registerSettings();
  registerStyles();
});

/**
 * Module ready hook - initialize subsystems and UI components
 */
Hooks.once("ready", async function () {
  console.log("TickPoint Combat | Initializing subsystems...");

  // Initialize core systems
  initializeAPTracker();
  initializeLongActions();
  initializeCustomActions();
  initializeTickTrackerUI();
  initializeQuickActions();
  initializeGMPanel();

  // Initialize and attach major components to global namespace
  game.tickpoint = game.tickpoint || {};

  // Instantiate singleton GM Panel
  if (!game.tickpoint.gmPanel) {
    game.tickpoint.gmPanel = new GMPanel();
  }

  // Instantiate singleton panels
  if (!game.tickpoint.customActionsPanel) {
    game.tickpoint.customActionsPanel = new CustomActionsPanel();
  }
  if (!game.tickpoint.quickActions) {
    game.tickpoint.quickActions = new QuickActionsPanel();
  }

  // Initialize TickScheduler singleton
  const maxTicks = getModuleSetting("maxTicks") ?? 20;
  const tickDuration = getModuleSetting("tickDuration") ?? 1000;

  TickSchedulerInstance.combat = game.combat || null;
  TickSchedulerInstance.maxTicks = maxTicks;
  TickSchedulerInstance.tickDuration = tickDuration;

  if (game.combat) {
    TickSchedulerInstance.initialize(game.combat);
  }

  setupModuleHooks();

  // Inject GM-only UI components
  if (game.user.isGM) {
    injectGMHistorySidebarButton();

    if (
      game.tickpoint.gmPanel &&
      typeof game.tickpoint.gmPanel.addButton === "function"
    ) {
      game.tickpoint.gmPanel.addButton("Manage Custom Actions", () => {
        game.tickpoint.customActionsPanel.render(true);
      });
    }
  }
});

/**
 * Hook registrations to manage lifecycle, UI updates, and cleanup
 */
function setupModuleHooks() {
  Hooks.on("createCombat", async (combat) => {
    if (!combat) return;
    TickSchedulerInstance.initialize(combat);
  });

  Hooks.on("updateCombat", async (combat, changes) => {
    if (!combat) return;
    if (changes.round !== undefined) {
      TickSchedulerInstance._onNewRound();
    }
  });

  Hooks.on("deleteCombat", async () => {
    TickSchedulerInstance.stop();
    destroyTickTrackerUI();
  });

  Hooks.on("updateActor", async (actor, changes) => {
    if (!actor) return;
    if (
      changes.system?.attributes?.speed !== undefined ||
      changes.flags?.["tickpoint-combat"] !== undefined
    ) {
      updateTickTrackerUI(TickSchedulerInstance.currentTick);
    }
  });

  Hooks.on("tickpoint-custom-action-used", (actor, action) => {
    // Placeholder for future logic
  });

  Hooks.on("tickpoint-ap-updated", (actor) => {
    if (!actor) return;
    if (game.tickpoint.quickActions) game.tickpoint.quickActions.render(true);
    if (game.tickpoint.gmPanel) game.tickpoint.gmPanel.render(true);
    updateTickTrackerUI(TickSchedulerInstance.currentTick);
  });

  Hooks.on("disableModule", async (moduleName) => {
    if (moduleName === "tickpoint-combat") {
      await performCleanup();
    }
  });

  Hooks.on("preUninstallModule", async (moduleName) => {
    if (moduleName === "tickpoint-combat") {
      await performCleanup();
    }
  });

  Hooks.on("renderSceneControls", () => {
    if (getModuleSetting("showQuickActionPanel")) {
      game.tickpoint.quickActions?.render(true);
    } else {
      game.tickpoint.quickActions?.close();
    }

    if (getModuleSetting("showGMPanel")) {
      game.tickpoint.gmPanel?.render(true);
    } else {
      game.tickpoint.gmPanel?.close();
    }
  });
}

/**
 * Shutdown cleanup
 */
Hooks.on("shutdown", async () => {
  console.log("TickPoint Combat | Cleaning up module flags and UI...");

  for (const actor of game.actors.contents) {
    if (actor?.getFlag("tickpoint-combat", "currentAP") !== undefined) {
      await actor.unsetFlag("tickpoint-combat", "currentAP");
      await actor.unsetFlag("tickpoint-combat", "maxAP");
    }
  }

  clearTemporaryUIElements();

  if (game.user.isGM) {
    const confirm = await confirmDeleteLogs();
    if (confirm) {
      await game.settings.set("tickpoint-combat", "actionHistoryLog", []);
      ui.notifications.info("TickPoint Combat | Logs deleted.");
    }
  }
});

/**
 * Inject a GM-only sidebar button to open the TickPoint Combat GM panel
 */
function injectGMHistorySidebarButton() {
  Hooks.on("renderSidebarTab", (app, html) => {
    if (app.options.id !== "chat" || !game.user.isGM) return;

    const button = $(
      `<button class="tickpoint-history-log-button" title="Open TickPoint Combat Log">
        <i class="fas fa-clipboard-list"></i> TickPoint Log
      </button>`
    );

    button.on("click", () => {
      game.tickpoint?.gmPanel?.render(true);
    });

    const controlArea = html.find(".directory-footer");
    controlArea.append(button);
  });
}

/**
 * Cleanup helper
 */
async function performCleanup() {
  for (const actor of game.actors.contents) {
    await actor.unsetFlag("tickpoint-combat", "currentAP");
    await actor.unsetFlag("tickpoint-combat", "maxAP");
  }
  clearTemporaryUIElements();
  ui.notifications.info("TickPoint Combat | Cleanup completed.");
}
