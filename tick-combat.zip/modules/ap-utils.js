// File: modules/tickpoint-combat/scripts/ap-utils.js

import { getModuleSetting } from "./settings.js";

/**
 * Evaluate the Speed formula from settings for a given actor.
 * Default formula: "(DEX + SIZ + INT) / 3"
 * Returns an integer number of ticks per round (speed).
 * Provides safe fallback to 1 if error or invalid result.
 * @param {Actor} actor
 * @returns {number}
 */
export function getActorSpeedTicks(actor) {
  if (!actor) return 1;
  const formula = getModuleSetting("speedFormula") || "(DEX + SIZ + INT) / 3";
  try {
    // Extract attributes from actor data, fallback to 0
    const data = actor.data.data || {};
    const DEX = Number(data.attributes?.dex?.value ?? data.dex ?? 0);
    const SIZ = Number(data.attributes?.siz?.value ?? data.siz ?? 0);
    const INT = Number(data.attributes?.int?.value ?? data.int ?? 0);

    // Eval formula safely with limited scope
    const speed = Function("DEX", "SIZ", "INT", `return Math.floor(${formula});`)(DEX, SIZ, INT);

    if (typeof speed !== "number" || speed < 1 || isNaN(speed)) return 1;
    return Math.floor(speed);
  } catch (err) {
    console.error("TickPoint Combat | Error evaluating speed formula:", err);
    return 1;
  }
}

/**
 * Evaluate the Max AP formula from settings for a given actor.
 * Default formula: "Math.floor(getActorSpeedTicks(actor) * 2)"
 * Returns integer max AP.
 * Provides safe fallback to 5 if error or invalid result.
 * @param {Actor} actor
 * @returns {number}
 */
export function getMaxAP(actor) {
  if (!actor) return 5;
  const formula = getModuleSetting("maxAPFormula") || "Math.floor(getActorSpeedTicks(actor) * 2)";
  try {
    // Use getActorSpeedTicks helper in formula scope
    const maxAP = Function("actor", "getActorSpeedTicks", `return Math.floor(${formula});`)(actor, getActorSpeedTicks);

    if (typeof maxAP !== "number" || maxAP < 1 || isNaN(maxAP)) return 5;
    return Math.floor(maxAP);
  } catch (err) {
    console.error("TickPoint Combat | Error evaluating Max AP formula:", err);
    return 5;
  }
}

/**
 * Get the current AP value of an actor from flags.
 * Returns 0 if not set.
 * @param {Actor} actor
 * @returns {number}
 */
export function getCurrentAP(actor) {
  if (!actor) return 0;
  const currentAP = actor.getFlag("tickpoint-combat", "currentAP");
  return Number(currentAP ?? 0);
}

/**
 * Set the current AP value for an actor.
 * Clamps value between 0 and max AP.
 * @param {Actor} actor
 * @param {number} value
 * @returns {Promise<void>}
 */
export async function setCurrentAP(actor, value) {
  if (!actor) return;
  const maxAP = getMaxAP(actor);
  const newAP = Math.min(Math.max(Math.floor(value), 0), maxAP);
  await actor.setFlag("tickpoint-combat", "currentAP", newAP);
  Hooks.call("tickpoint-ap-updated", actor);
}

/**
 * Deduct AP from actor by a specified cost.
 * Returns true if deduction successful, false if insufficient AP.
 * @param {Actor} actor
 * @param {number} cost
 * @returns {Promise<boolean>}
 */
export async function deductAP(actor, cost) {
  if (!actor) return false;
  if (typeof cost !== "number" || cost <= 0) return false;
  const current = getCurrentAP(actor);
  if (current < cost) return false;
  await setCurrentAP(actor, current - cost);
  return true;
}

/**
 * Restore AP to an actor by a specified amount.
 * Clamps to max AP.
 * @param {Actor} actor
 * @param {number} amount
 * @returns {Promise<void>}
 */
export async function restoreAP(actor, amount) {
  if (!actor) return;
  if (typeof amount !== "number" || amount <= 0) return;
  const current = getCurrentAP(actor);
  await setCurrentAP(actor, current + amount);
}

/**
 * Reset actor AP to max AP.
 * @param {Actor} actor
 * @returns {Promise<void>}
 */
export async function resetAP(actor) {
  if (!actor) return;
  const maxAP = getMaxAP(actor);
  await setCurrentAP(actor, maxAP);
}

/**
 * Initialize AP flags on actor, setting maxAP and currentAP.
 * @param {Actor} actor
 * @returns {Promise<void>}
 */
export async function initializeAP(actor) {
  if (!actor) return;
  const maxAP = getMaxAP(actor);
  await actor.setFlag("tickpoint-combat", "maxAP", maxAP);
  await setCurrentAP(actor, maxAP);
}

/**
 * Clear AP flags from an actor.
 * @param {Actor} actor
 * @returns {Promise<void>}
 */
export async function clearAPFlags(actor) {
  if (!actor) return;
  await actor.unsetFlag("tickpoint-combat", "maxAP");
  await actor.unsetFlag("tickpoint-combat", "currentAP");
  Hooks.call("tickpoint-ap-updated", actor);
}


